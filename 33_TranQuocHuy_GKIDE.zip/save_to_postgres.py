import json
import os
import requests
import psycopg

conn = psycopg.connect(
    dbname=os.getenv("DB_NAME", "catdb"),
    user=os.getenv("DB_USER", "postgres"),
    password=os.getenv("DB_PASSWORD", "password"),
    host=os.getenv("DB_HOST", "localhost"),
    port=5432
)

with conn.cursor() as cur:
    cur.execute("""
    CREATE TABLE IF NOT EXISTS cats (
        id TEXT PRIMARY KEY,
        name TEXT,
        origin TEXT,
        temperament TEXT[],
        life_span TEXT,
        image_url TEXT
    );
    """)

with open('cats_clean.json', 'r', encoding='utf-8') as f:
    cats = json.load(f)

os.makedirs('data/images', exist_ok=True)

with conn.cursor() as cur:
    for cat in cats:
        cur.execute("""
        INSERT INTO cats (id, name, origin, temperament, life_span, image_url)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO NOTHING;
        """, (
            cat['id'],
            cat['name'],
            cat['origin'],
            cat['temperament'],
            cat['life_span'],
            cat['image_url']
        ))

        try:
            img_data = requests.get(cat['image_url'], timeout=10).content
            with open(f"data/images/{cat['id']}.jpg", 'wb') as handler:
                handler.write(img_data)
        except Exception as e:
            print(f"❌ Lỗi tải ảnh {cat['id']}: {e}")

conn.commit()
conn.close()
print("✅ Dữ liệu đã lưu vào PostgreSQL và ảnh đã tải về.")
