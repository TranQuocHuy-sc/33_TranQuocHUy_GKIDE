from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

with DAG(
    'cat_pipeline',
    default_args={
        'retries': 2,
        'retry_delay': timedelta(minutes=5)
    },
    schedule_interval='0 9 * * *',
    start_date=datetime(2024, 1, 1),
    catchup=False
) as dag:

    crawl = BashOperator(
        task_id='crawl_cat',
        bash_command='python /app/crawl_cat.py'
    )

    transform = BashOperator(
        task_id='transform_cat',
        bash_command='python /app/transform_cat.py'
    )

    save = BashOperator(
        task_id='save_cat',
        bash_command='python /app/save_to_postgres.py'
    )

    crawl >> transform >> save
