import requests
import json

url = "https://api.thecatapi.com/v1/breeds"
response = requests.get(url)

if response.status_code == 200:
    cats = response.json()
    data = []
    for cat in cats:
        data.append({
            'id': cat.get('id'),
            'name': cat.get('name'),
            'origin': cat.get('origin'),
            'temperament': cat.get('temperament'),
            'life_span': cat.get('life_span'),
            'image_url': cat.get('image', {}).get('url')
        })
    with open('cats_raw.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
else:
    print("Failed to fetch data:", response.status_code)
