import json

with open('cats_raw.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for cat in data:
    temperament = cat.get('temperament')
    cat['temperament'] = [x.strip() for x in temperament.split(',')] if temperament else []
    if not cat.get('image_url'):
        cat['image_url'] = 'https://cdn2.thecatapi.com/images/aae.jpg'

with open('cats_clean.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
